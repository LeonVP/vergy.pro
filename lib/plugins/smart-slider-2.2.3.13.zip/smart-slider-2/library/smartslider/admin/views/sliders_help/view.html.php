<?php

class NextendSmartsliderAdminViewSliders_help extends NextendView{
    
}
