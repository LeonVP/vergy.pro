<?php

class NextendSmartsliderAdminControllerHelp extends NextendSmartsliderAdminController {

    function defaultAction() {

        $this->display('default', 'default');
    }

}