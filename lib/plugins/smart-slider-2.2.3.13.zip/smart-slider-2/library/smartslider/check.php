<?php

function smartsliderIsFull(){
    return false;
}